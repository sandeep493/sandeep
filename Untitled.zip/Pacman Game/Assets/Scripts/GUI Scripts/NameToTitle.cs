﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class NameToTitle : MonoBehaviour {

	public Text title;


	void OnMouseEnter()
	{
		switch(name)
		{
		case "Pac-Man":
			title.color = Color.magenta;
			break;

		case "Blinky":
			title.color = Color.red;
			break;

		case "Pinky":
			title.color = Color.green;
			break;

		case "Inky":
			title.color = Color.cyan;
			break;

		case "Clyde":
			title.color = Color.blue;
			break;
		}
		
		title.text = name;
	}

	void OnMouseExit()
	{
		title.text = "Pac-Man Game";
		title.color = Color.yellow;
	}
}
